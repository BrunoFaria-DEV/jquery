$(function() {
    $('button').on('click', function(e) {
        e.preventDefault();
        $('p').hide();
    })
});